#pragma GCC system_header
static constinit ResourceInitHelper res_init _LIBCPP_INIT_PRIORITY_MAX;
